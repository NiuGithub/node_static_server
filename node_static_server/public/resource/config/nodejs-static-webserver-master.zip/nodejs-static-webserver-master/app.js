const StaticServer = require('./static-server');

(new StaticServer()).start();